﻿using System;

namespace lab04
{
    class Program
    {
        public static void Main(String[] args)
        {
            int a = 1, b = 3, c = 5;

            double x = 2.2, y = 4.4, z = 6.6, ans;

            ans = average(a, b);

            Console.WriteLine("\naverage(a, b) = " + ans);

            ans = average(a, b, c);

            Console.WriteLine("\naverage(a, b, c) = " + ans);

            ans = average(x, y);

            Console.WriteLine("\naverage(x, y) = " + ans);

            ans = average(x, y, z);

            Console.WriteLine("\naverage(x, y, z) = " + ans);

            ans = average(average(a, b), c);

            Console.WriteLine("\naverage(a, b, c) = " + ans);

            ans = average(1, 2.0, 3);

            Console.WriteLine("\naverage(1, 2.0, 3) = " + ans);

        }

        public static double average(double a, double b)
        {

            return ((a + b) / 2.0);

        }

        public static double average(double a, double b, double c)
        {

            return ((a + b + c) / 3.0);

        }

    }
}


//1. we do not need the int version as the double version will accept the both integer and double.
//2. since (average(a,b),c)!= average(a,b,c) we need to have three parameter version
//3. yes, average(1,2.0,3) is legal as it is accepted by the double parameters overload method.
// i.e public static double Average(double a, double b, double c)