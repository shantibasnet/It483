﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab02
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("---Welcome to Glass Store--- \n");
            Console.WriteLine("Prescription glass price = $40.00 \n");
            Console.WriteLine("Non-prescription glass price = $25.00 \n");
            Console.WriteLine("Anti-glare coating price = $12.50\n");
            Console.WriteLine("Brown-tint coating price = $9.99 \n");
            Console.WriteLine("------------------------------- \n");

            bool b1 = true;
            bool b2 = true;
            int glasstype = 0;
            int coating = 0;
            double totalCost = 0;

            Console.WriteLine("what kind of glasses would you like: \n");

            while (b1)
            {
                Console.Write("1 -> prescription, 2 -> non-prescription :");
                glasstype = int.Parse(Console.ReadLine());

                if (glasstype == 1 || glasstype == 2)
                {
                    b1 = false;
                }
            }
            Console.WriteLine("What Kind of coating would you like:");
            while (b2)
            {
                Console.Write("1 -> anti-glare, 2 -> brown tint:");
                coating = int.Parse(Console.ReadLine());

                if (coating == 1 || coating == 2)
                {
                    b2 = false;
                }
            }

            if (glasstype == 1)
            {
                totalCost += 40;
            }
            else
            {
                totalCost += 25;
            }
            if (coating == 1)
            {
                totalCost += 12.50;
            }
            else
            {
                totalCost += 9.99;
            }

            Console.Write("\n your total cost is: $" + totalCost);



        }
    }
}
