﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Lab01
{
    public static void Main()
    {
        //to print an output and \n for line break
        Console.WriteLine("CS 201 Restaurant Guide\n");
        String response;
        char s;
        char f;
        bool fancy;
        bool spicy;
        //Ask user for his/her preference
        Console.Write("Do you like spicy food? (y/n):");

        response = Console.ReadLine();
        //Console.ReadLine() is used to take input a string

        s = response[0];
        if ((s == 'y') || (s == 'Y'))
            spicy = true;
        else
            spicy = false;

        Console.Write("Do you want to go to a fancy restaurant? (y/n):");
        //get the next token response
        response = Console.ReadLine();
        //look only at first character
        f = response[0];
        fancy = (f == 'y') || (f == 'Y');
        //Make suggestion if
        //if block
        if (spicy)
        {     
            if (fancy)
                Console.WriteLine("I suggest you go to Thai Garden Palace.");
            else
                Console.WriteLine("I suggest you go to Alberto's Tacqueria.");
        }
        else
        //else block
        {    
            if (fancy)
                Console.WriteLine("I suggest you go to Chez Paris.");
            else
                Console.WriteLine("I suggest you go to Joe's Diner.");
        }
    }
}